<?php
//setting header to json
header('Content-Type: application/json');
//contentType: "text/plain"; //chrome
//header('Content-Type: application/json; charset=UTF8');
//database

$servername = "localhost";
$username = "root";
$pass = "";
$dbname = "datalogging";

/*
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'datalogging');
*/

//get connection
//$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
$mysqli = new mysqli($servername, $username, $pass, $dbname);

if(!$mysqli)
{
	die("Connection failed: " . $mysqli->error);
}
//query to get data from the table
$query = sprintf("SELECT DateTime, Gas FROM gas_and_temp");
//execute query
$result = $mysqli->query($query);
//loop through the returned data
$data = array();
foreach ($result as $row) 
{
	$data[] = $row;
}
//free memory associated with result
$result->close();
//close connection
$mysqli->close();
//now print the data
print json_encode($data);
?>