<?php

$connect = mysqli_connect("localhost", "root", "", "datalogging");
$query = "SELECT * FROM gas_and_temp ORDER BY id DESC";
$result = mysqli_query($connect, $query);


?>