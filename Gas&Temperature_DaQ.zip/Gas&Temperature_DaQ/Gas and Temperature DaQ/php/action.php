<?php  
//action.php
$connect = mysqli_connect('localhost', 'root', '', 'datalogging');

$input = filter_input_array(INPUT_POST);

$first_name = mysqli_real_escape_string($connect, $input["Gas"]);
$last_name = mysqli_real_escape_string($connect, $input["Temperature"]);

if($input["action"] === 'edit')
{
 $query = "
 UPDATE gas_and_temp 
 SET Gas = '".$first_name."', 
 Temperature = '".$last_name."' 
 WHERE id = '".$input["ID"]."'
 ";

 mysqli_query($connect, $query);

}
if($input["action"] === 'delete')
{
 $query = "
 DELETE FROM Gas
 WHERE id = '".$input["ID"]."'
 ";
 mysqli_query($connect, $query);
}

echo json_encode($input);

?>